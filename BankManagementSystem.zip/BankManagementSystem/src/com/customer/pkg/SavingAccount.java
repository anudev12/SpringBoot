package com.customer.pkg;

public class SavingAccount extends Account{
	public String accountno;
	public String balance;
	
	
}
