package com.customer.pkg;

public class ATMTransaction {
	public Integer transactionid;
	public Integer date;
	public String type;
	public double amount;
	public double postbalance;
	public ATMTransaction(Integer transactionid, Integer date, String type, double amount, double postbalance) {
		super();
		this.transactionid = transactionid;
		this.date = date;
		this.type = type;
		this.amount = amount;
		this.postbalance = postbalance;
	}
	
	public String modifies() {
		return "modifies";
		
	}

}
