package com.customer.pkg;

import java.util.Date;

public class ATM extends Bank {

	public String locaton;
	public String managedby;

	public String identifies() {
		return "identifies";

	}

	public String transactions() {
		return "transactions";

	}

	Integer transactionid = 0;

	public String withDraw(String accountType, double withDrawAmount) throws Exception {
		if ("Saving".equalsIgnoreCase(accountType)) {
			SavingAccount savingAccount = new SavingAccount();
			String response = savingAccount.withdrow(withDrawAmount);

			transactionid++;
			ATMTransaction captureTransationDetaoils = new ATMTransaction(transactionid, new Date().getDate(),
					accountType, withDrawAmount, savingAccount.getCurrentBalance());

			return response;
		}
		if ("Current".equalsIgnoreCase(accountType))
			return new CurrencyAccount().withdrow(withDrawAmount);

		return "Please provide correct account Type";

	}

	public String deposite(String accountType, double withDrawAmount) throws Exception {
		if ("Saving".equalsIgnoreCase(accountType))
			return new SavingAccount().deposite(withDrawAmount);
		if ("Current".equalsIgnoreCase(accountType))
			return new CurrencyAccount().deposite(withDrawAmount);

		return "Please provide correct account Type";

	}

}
