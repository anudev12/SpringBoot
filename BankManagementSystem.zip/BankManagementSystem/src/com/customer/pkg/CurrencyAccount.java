package com.customer.pkg;

public class CurrencyAccount extends Account{
	public String accountno;
	public double balance;
	

	public String withdrow(long withDrawAmount) throws Exception {
		if(balance>withDrawAmount) {
			this.balance=this.balance-withDrawAmount;
			return "With draw for currency Account ";
		}else {
			throw new Exception("don't have sufficient balance for currency Account");
		}
		
		
	}

}
