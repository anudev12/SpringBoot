package com.customer.pkg.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.stream.LongStream;

public class Permutations {
	private Permutations() {
	}

	public static long factorial(int n) {
		if (n > 20 || n < 0)
			throw new IllegalArgumentException(n + " is out of range");
		return LongStream.rangeClosed(2, n).reduce(1, (a, b) -> a * b);
	}

	public static <T> List<T> permutation(long no, List<T> items) {
		return permutationHelper(no, new LinkedList<>(Objects.requireNonNull(items)), new ArrayList<>());
	}

	private static <T> List<T> permutationHelper(long no, LinkedList<T> in, List<T> out) {
		if (in.isEmpty())
			return out;
		long subFactorial = factorial(in.size() - 1);
		out.add(in.remove((int) (no / subFactorial)));
		return permutationHelper((int) (no % subFactorial), in, out);
	}

	

	public static void main(String[] args) {

		List<String> items = Arrays.asList("alpha", "beta", "gamma");
		long permutations = Permutations.factorial(items.size());
		LongStream.range(0, permutations).forEachOrdered(i -> {
			System.out.println(i + ": " + Permutations.permutation(i, items));
		});
	}
}