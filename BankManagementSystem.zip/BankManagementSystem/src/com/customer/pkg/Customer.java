package com.customer.pkg;

public class Customer {

	public String name;
	public String address;
	public String dob;
	public String cardnumber;
	public String pin;
	public Customer(String name, String address, String dob, String cardnumber, String pin) {
		super();
		this.name = name;
		this.address = address;
		this.dob = dob;
		this.cardnumber = cardnumber;
		this.pin = pin;
	}
	
	public String verifyPassword(String password) {
		
		return "success";
		
	}
	
	
}
