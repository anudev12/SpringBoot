package com.customer.pkg;

public class Account {
	public String number;
	public double balance;
	
	public String deposite(double depositAmount) {
		this.balance=this.balance+depositAmount;
		return "Deposit Success";
		
	}
	
	public String withdrow(double withDrawAmount) throws Exception {
		if(balance>withDrawAmount) {
			this.balance=this.balance-withDrawAmount;
			return "With draw completed ";
		}else {
			throw new Exception("don't have sufficient balance");
		}
		
		
	}
	
	public String createTrasaction(double transationAmount) throws Exception {
		if(balance>transationAmount) {
			this.balance=this.balance-transationAmount;
			return "Transation completed ";
		}else {
			throw new Exception("don't have sufficient balance");
		}
		
	}
	
	public double getCurrentBalance() {
		return balance;
	}
}
