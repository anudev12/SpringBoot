package com.customer.pkg;

public class Bank {
	public Integer code;
	public String address;
	
	public String manages() {
		return "Manage Bank";
	}
	
	public String mainTains() {
		return "Maintains Bank";
	}
}
