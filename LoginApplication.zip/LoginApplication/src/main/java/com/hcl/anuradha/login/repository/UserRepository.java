package com.hcl.anuradha.login.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcl.anuradha.login.bean.UserInfo;

public interface UserRepository extends JpaRepository<UserInfo, Integer> {
	
	//public List<UserInfo> findByUserNameContainingIgnoreCase(String userName);
	
	public UserInfo findByUsernameContainingIgnoreCase(String userName);
	

}
