package com.hcl.anuradha.login.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.anuradha.login.bean.UserInfo;
import com.hcl.anuradha.login.bean.UserResponse;
import com.hcl.anuradha.login.repository.UserRepository;



@RestController
@RequestMapping("/api")
public class LoginController {
	@Autowired
	UserRepository userRepo;
	
	Map<String, UserInfo> localSession=new HashMap<>();
	
	@PostMapping(path = "/saveuserinfo")
	public String saveUserInfo(@RequestBody UserInfo data) {
		userRepo.save(data);
		return "User Info Save Successfully" ;
	}
	
	@PostMapping(path = "/login")
	public String loginUser(@RequestBody UserInfo userInfo) {
		UserInfo userInfoRes=userRepo.findByUsernameContainingIgnoreCase(userInfo.getUsername());
		if(userInfoRes.getUsername().equals(userInfo.getUsername())&&userInfoRes.getPassword().equals(userInfo.getPassword())) {
			localSession.put(userInfo.getUsername(), userInfoRes);
			return "login Success";
			
		}else {
			return "Invalid login details ";
		}
		
	}
	@GetMapping(path = "/userinfo/{username}")
	@ResponseBody
	public UserResponse getAllDataByName(@PathVariable(name = "username") String username) throws Exception {
		UserResponse userResponse=new UserResponse();
		UserInfo userInfo=localSession.get(username);
		if(userInfo!=null) {
			userResponse.setFirstname(userInfo.getFirstname());
			userResponse.setLastname(userInfo.getLastname());
			return userResponse;
		}else {
			throw new Exception("Please login, no session found");
		}
		
		
	}
	@GetMapping(path = "/logout/{username}")
	@ResponseBody
	public String logoutUser(@PathVariable(name = "username") String username) {
		
		if(localSession.containsKey(username)) {
			localSession.remove(username);
			return "success";
		}
		return "Please Login first, then logout";
	}
	
	
}
